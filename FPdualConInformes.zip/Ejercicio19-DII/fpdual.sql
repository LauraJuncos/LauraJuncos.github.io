-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-02-2025 a las 12:34:43
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fpdual`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnado`
--

CREATE TABLE `alumnado` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `dni` varchar(9) NOT NULL,
  `ciclo_formativo` enum('CFGB','SMR','DAM') NOT NULL,
  `curso` int(11) DEFAULT NULL CHECK (`curso` in (1,2)),
  `participando` tinyint(1) DEFAULT 0
) ;

--
-- Volcado de datos para la tabla `alumnado`
--

INSERT INTO `alumnado` (`id`, `nombre`, `dni`, `ciclo_formativo`, `curso`, `participando`) VALUES
(14, 'Laura García', '12345678A', 'CFGB', 2, 1),
(15, 'Carlos Pérez', '23456789B', 'CFGB', 1, 0),
(16, 'Ana López', '34567890C', 'SMR', 1, 0),
(17, 'Javier Ruiz', '45678901D', 'SMR', 2, 1),
(18, 'Beatriz Sánchez', '56789012E', 'DAM', 2, 1),
(19, 'David Fernández', '67890123F', 'DAM', 2, 1),
(20, 'Marta Rodríguez', '78901234G', 'SMR', 1, 0),
(21, 'Sergio Martín', '89012345H', 'CFGB', 2, 1),
(22, 'Isabel Gómez', '90123456I', 'DAM', 2, 1),
(23, 'Pablo Díaz', '01234567J', 'SMR', 1, 0),
(24, 'Laura López', '49429523Q', 'DAM', 2, 1),
(25, 'Toñi Ramírez', '74504706R', 'CFGB', 1, 0),
(27, 'Laura Juncos', '49429523L', 'DAM', 2, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnado`
--
ALTER TABLE `alumnado`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dni` (`dni`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnado`
--
ALTER TABLE `alumnado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
